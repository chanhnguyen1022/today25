package fjs.cs.hibernate;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="MSTCUSTOMER")
public class MSTCUSTOMER implements java.io.Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Column(name="CUSTOMER_ID")
	private int Customer_Id;
	
	@Column(name="CUSTOMER_NAME")
	private String Customer_Name;
	
	@Column(name="SEX")
	private String sex;
	
	@Column(name="BIRTHDAY")
	private String birthDay;
	
	@Column(name="EMAIL")
	private String email;
	
	@Column(name="ADDRESS")
	private String address;
	
	@Column(name="DELETE_YMD")
	private Date delete_ymd;
	
	@Column(name="INSERT_YMD")
	private Date insert_ymd;
	
	@Column(name="INSERT_PSN_CD")
	private int insert_psn_cd;
	
	@Column(name="UPDATE_YMD")
	private Date update_ymd;
	
	@Column(name="UPDATE_PSN_CD")
	private int update_psn_cd;

	public int getCustomer_Id() {
		return Customer_Id;
	}

	public void setCustomer_Id(int customer_Id) {
		Customer_Id = customer_Id;
	}

	public String getCustomer_Name() {
		return Customer_Name;
	}

	public void setCustomer_Name(String customer_Name) {
		Customer_Name = customer_Name;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getBirthDay() {
		return birthDay;
	}

	public void setBirthDay(String birthDay) {
		this.birthDay = birthDay;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Date getDelete_ymd() {
		return delete_ymd;
	}

	public void setDelete_ymd(Date delete_ymd) {
		this.delete_ymd = delete_ymd;
	}

	public Date getInsert_ymd() {
		return insert_ymd;
	}

	public void setInsert_ymd(Date insert_ymd) {
		this.insert_ymd = insert_ymd;
	}

	public int getInsert_psn_cd() {
		return insert_psn_cd;
	}

	public void setInsert_psn_cd(int insert_psn_cd) {
		this.insert_psn_cd = insert_psn_cd;
	}

	public Date getUpdate_ymd() {
		return update_ymd;
	}

	public void setUpdate_ymd(Date update_ymd) {
		this.update_ymd = update_ymd;
	}

	public int getUpdate_psn_cd() {
		return update_psn_cd;
	}

	public void setUpdate_psn_cd(int update_psn_cd) {
		this.update_psn_cd = update_psn_cd;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}