package fjs.cs.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import fjs.cs.common.ConnectDB;

public class UserDaoImpl extends HibernateDaoSupport implements UserDao{

	@Override
	public boolean authenticate(String UserId, String Password) {
		ResultSet rs = null;
		
		try {
			Connection conn = this.getSession().connection();
	
			//Cau lenh sql truy van du lieu userid va passwrod trong table MSTUSER.
			String sql = "SELECT COUNT(*) AS CNT FROM MSTUSER WHERE USERID=? AND PASSWORD=? AND DELETE_YMD IS NULL";
			//Lay du lieu userid va password tu table MSTUSER.
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, UserId);
			ps.setString(2, Password);
//			ps.setDate(3, (java.sql.Date) Delete_YMD);
			rs = ps.executeQuery();
			rs.next();
			int cnt = rs.getInt("CNT");
			//Check User Id / Password ton tai trong table MSTUSER		
			if (cnt==1) {
			//Truong hop userid va password hop le return true.
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
			

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		//Truong hop userid va password hop le return false.
		return false;
	}

}
