package fjs.cs.dao;
import fjs.cs.hibernate.MSTUSER;
public interface UserDao {
	public boolean authenticate(String UserId, String Password);
}
