package fjs.cs.dao;

public interface UserBo {
	public boolean authenticate(String UserId, String Password);
}
