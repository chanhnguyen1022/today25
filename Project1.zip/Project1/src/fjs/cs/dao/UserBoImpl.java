package fjs.cs.dao;

public class UserBoImpl implements UserBo {

	@Override
	public boolean authenticate(String UserId, String Password) {
		// TODO Auto-generated method stub
		return false;
	}

}
