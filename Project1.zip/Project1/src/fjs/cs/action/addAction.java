/**
 * @(#)addAction.java 01-00 2017/08/16.
 * Copyright(C) FUJINET CO., LTD.
 *
 * Version 1.00.
 */
package fjs.cs.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.springframework.web.struts.ActionSupport;

import fjs.cs.dao.CustomerBo;
import fjs.cs.dao.MSTCUSTOMERDAO;
import fjs.cs.action.form.EditForm;
import fjs.cs.action.form.SearchForm;

/**
 * addAction
 * 
 * @author chanh-nm 2017/08/21
 * @version 1.00
 */
public class addAction extends ActionSupport {

	/**
	 * ActionMapping mapping ActionForm form HttpServletRequest request
	 * HttpServletResponse response
	 */
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		
		EditForm editForm = (EditForm) form;

		HttpSession session;
		
		String name;
		session = request.getSession();
		name = (String) session.getAttribute("username");
		
//		CustomerBo dao=(CustomerBo) getWebApplicationContext().getBean("customerBo");
		MSTCUSTOMERDAO dao = new MSTCUSTOMERDAO();
		
		int PSN_CD = dao.getPSNCDbyUsername(name);
	
		editForm.setInsertPSN(PSN_CD);

		dao.addCustomer(editForm);
		session.setAttribute("message", "true");
		SearchForm searchForm = (SearchForm) session.getAttribute("searchForm");
	
		if(searchForm == null){
			return mapping.findForward("result2");
		}

		return mapping.findForward("result1");
	}
}