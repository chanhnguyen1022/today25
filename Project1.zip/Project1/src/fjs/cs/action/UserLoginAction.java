/**
 * @(#)UserLoginAction.java 01-00 2017/08/16.
 * Copyright(C) FUJINET CO., LTD.
 *
 * Version 1.00.
 */
package fjs.cs.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.*;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.springframework.web.struts.ActionSupport;

import fjs.cs.action.form.UserLoginForm;
import fjs.cs.dao.MSTUSERDAO;
/**
 * UserLoginAction
 *
 * @author chanh-nm 2017/08/21
 * @version 1.00
 */
public class UserLoginAction extends ActionSupport {
	/**
	 * ActionMapping mapping
	 * ActionForm form
	 * HttpServletRequest request
	 * HttpServletResponse response
	 */	
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		
		UserLoginForm loginForm = (UserLoginForm) form;

		String username = loginForm.getUserId();
	
		String password = loginForm.getPassword();
				

		boolean checkLoginFlg = false;
		
//		UserBo dao=(UserBo) getWebApplicationContext().getBean("userBo");
		MSTUSERDAO dao = new MSTUSERDAO();
		checkLoginFlg = dao.authenticate(username,password);

	
		if (checkLoginFlg) {
			
			HttpSession se = request.getSession();
			se.setAttribute("username", username);
			return mapping.findForward("success");
		}else {
			

			String error="ユーザーIDまたはパスワードが不正です。";
			request.setAttribute("lblErrorMessage",error);
		}
		return mapping.findForward("failure");
		
	}

}