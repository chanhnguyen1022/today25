package fjs.cs.hibernate;


import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="MSTUSER")
public class MSTUSER implements java.io.Serializable{

		/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
		@Column(name="PSN_CD")
		private int psn_cd;
		
		@Column(name="USERID")
		private String userId;
		
		@Column(name="PASSWORD")
		private String password;
		
		@Column(name="USERNAME")
		private String username;
		
		@Column(name="DELETE_YMD")
		private Date delete_ymd;
		
		@Column(name="INSERT_YMD")
		private Date insert_ymd;
		
		@Column(name="INSERT_PSN_CD")
		private int insert_psn_cd;
		
		@Column(name="UPDATE_YMD")
		private Date update_ymd;
		
		@Column(name="UPDATE_PSN_CD")
		private int update_psn_cd;
		
		public int getPsn_cd() {
			return psn_cd;
		}
		public void setPsn_cd(int psn_cd) {
			this.psn_cd = psn_cd;
		}
		public String getUserid() {
			return userId;
		}
		public void setUserid(String userid) {
			this.userId = userid;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		public String getUsername() {
			return username;
		}
		public void setUsername(String username) {
			this.username = username;
		}
		public Date getDelete_ymd() {
			return delete_ymd;
		}
		public void setDelete_ymd(Date delete_ymd) {
			this.delete_ymd = delete_ymd;
		}
		public Date getInsert_ymd() {
			return insert_ymd;
		}
		public void setInsert_ymd(Date insert_ymd) {
			this.insert_ymd = insert_ymd;
		}
		public int getInsert_psn_cd() {
			return insert_psn_cd;
		}
		public void setInsert_psn_cd(int insert_psn_cd) {
			this.insert_psn_cd = insert_psn_cd;
		}
		public Date getUpdate_ymd() {
			return update_ymd;
		}
		public void setUpdate_ymd(Date update_ymd) {
			this.update_ymd = update_ymd;
		}
		public int getUpdate_psn_cd() {
			return update_psn_cd;
		}
		public void setUpdate_psn_cd(int update_psn_cd) {
			this.update_psn_cd = update_psn_cd;
		}

		
}
